## Download datasets

Navigate to https://www.kaggle.com/c/home-credit-default-risk/data

Press the "Download All" button

When finished downloading unzip the all.zip into the git repo's input/ directory.

